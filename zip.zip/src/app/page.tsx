'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { CheckCircle2, Users, Star, Award, ArrowRight } from 'lucide-react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';

const doctorImage = PlaceHolderImages.find(img => img.id === 'doctor-profile-hero') || {
  imageUrl: 'https://picsum.photos/seed/doctor/600/800',
  description: 'Dr. Evelyn Reed',
  imageHint: 'doctor professional'
};

const clinicHero = PlaceHolderImages.find(img => img.id === 'clinic-interior-lobby') || {
  imageUrl: 'https://picsum.photos/seed/clinic/1200/600',
  description: 'Maple Clinic Lobby',
  imageHint: 'clinic lobby'
};

const stats = [
  { label: 'Patients Treated', value: '5,000+', icon: Users },
  { label: 'Years Experience', value: '15+', icon: Award },
  { label: 'Patient Rating', value: '4.9/5', icon: Star },
  { label: 'Care Awards', value: '12', icon: CheckCircle2 },
];

export default function HomePage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const heroY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const heroOpacity = useTransform(scrollYProgress, [0, 1], [1, 0.6]);

  return (
    <main className="overflow-x-hidden animate-fast-in">
      {/* Hero Section */}
      <section ref={heroRef} className="relative h-[85vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        <motion.div 
          style={{ y: heroY, opacity: heroOpacity }}
          className="absolute inset-0 z-0"
        >
          <Image
            src={clinicHero.imageUrl}
            alt={clinicHero.description}
            fill
            className="object-cover brightness-[0.4]"
            priority
            data-ai-hint={clinicHero.imageHint}
          />
        </motion.div>
        
        <div className="container relative z-10 mx-auto px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6 tracking-tight">
              Your Health, <br/><span className="text-primary italic">Our Priority</span>
            </h1>
            <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-10 text-slate-200 font-light">
              Expert medical care delivered with compassion and advanced technology at Maple Clinic.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/contact" className="contents">
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.96 }}>
                  <Button size="lg" className="w-full sm:w-auto text-lg px-8 py-7 group shadow-lg">
                    Book Your Visit
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Button>
                </motion.div>
              </Link>
              <Link href="/services" className="contents">
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.96 }}>
                  <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8 py-7 bg-white/10 backdrop-blur-md text-white border-white/50 hover:bg-white hover:text-primary transition-all duration-200 shadow-lg">
                    Explore Services
                  </Button>
                </motion.div>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-primary/5 py-16 border-y">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div 
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="text-center group"
              >
                <div className="inline-flex p-4 rounded-full bg-white shadow-sm text-primary mb-4 transition-transform group-hover:scale-110">
                  <stat.icon className="h-7 w-7" />
                </div>
                <div className="text-3xl font-bold text-primary mb-1">{stat.value}</div>
                <div className="text-sm uppercase tracking-wider text-muted-foreground font-semibold">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Doctor Section */}
      <section className="container mx-auto px-4 py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl"
          >
            <Image
              src={doctorImage.imageUrl}
              alt={doctorImage.description}
              fill
              className="object-cover"
              data-ai-hint={doctorImage.imageHint}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
          </motion.div>
          
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="inline-block px-4 py-1.5 rounded-full bg-accent/20 text-accent-foreground text-xs font-bold tracking-widest uppercase mb-4">
                Lead Physician
              </div>
              <h2 className="text-4xl md:text-5xl font-headline font-bold text-primary mb-6">Meet Dr. Evelyn Reed</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                With over 15 years of experience in family medicine, Dr. Reed has treated thousands of patients across Ottawa. Her approach combines evidence-based medicine with a deep commitment to patient empowerment.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
                {[
                  'Preventative Health',
                  'Board Certified',
                  'Personalized Care',
                  'Advanced Diagnostics'
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3 text-muted-foreground bg-muted/30 p-3 rounded-xl">
                    <CheckCircle2 className="h-5 w-5 text-accent shrink-0" />
                    <span className="font-medium">{item}</span>
                  </div>
                ))}
              </div>
              <Link href="/about" className="contents">
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.96 }}>
                  <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-white transition-all w-full sm:w-auto">
                    Full Biography
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="bg-muted/30 py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Our Services', desc: 'Comprehensive medical care.', link: '/services', action: 'View Services' },
              { title: 'Patient Reviews', desc: 'Hear from our community.', link: '/reviews', action: 'Read Stories' },
              { title: 'Book Today', desc: 'Easy online scheduling.', link: '/contact', action: 'Schedule Now', primary: true }
            ].map((card, i) => (
              <motion.div
                key={card.title}
                whileHover={{ y: -5 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card className={`h-full border-none shadow-md overflow-hidden ${card.primary ? 'bg-primary text-primary-foreground' : 'bg-white/80 backdrop-blur-sm'}`}>
                  <CardHeader>
                    <CardTitle className={`font-headline ${card.primary ? 'text-white' : 'text-primary'}`}>{card.title}</CardTitle>
                    <CardDescription className={card.primary ? 'text-white/80' : ''}>{card.desc}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Link href={card.link}>
                      <Button variant={card.primary ? 'secondary' : 'link'} className={`p-0 ${card.primary ? 'w-full' : 'text-primary font-bold'}`}>
                        {card.action} {card.primary ? '' : '→'}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}