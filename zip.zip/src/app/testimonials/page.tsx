import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';

// Placeholder for patient avatars, fetched from placeholder-images.json
const patientAvatars = [
  PlaceHolderImages.find(img => img.imageHint === 'patient avatar') || { imageUrl: 'https://picsum.photos/seed/patient1/100/100', description: 'Patient Avatar 1', imageHint: 'patient avatar'},
  PlaceHolderImages.find(img => img.imageHint === 'patient avatar') || { imageUrl: 'https://picsum.photos/seed/patient2/100/100', description: 'Patient Avatar 2', imageHint: 'patient avatar'},
  PlaceHolderImages.find(img => img.imageHint === 'patient avatar') || { imageUrl: 'https://picsum.photos/seed/patient3/100/100', description: 'Patient Avatar 3', imageHint: 'patient avatar'},
];

// Mock data for testimonials
const testimonialsData = [
  {
    quote: "Dr. Reed and her staff are exceptionally kind and knowledgeable. I always feel heard and well-cared for. Maple Clinic has truly made a difference in my health journey.",
    name: "Sarah K.",
    avatar: patientAvatars[0],
  },
  {
    quote: "The clinic is always clean, welcoming, and runs efficiently. Dr. Reed's clear explanations and proactive approach to my health have been invaluable. Highly recommend!",
    name: "Mark T.",
    avatar: patientAvatars[1],
  },
  {
    quote: "I was initially nervous about finding a new doctor, but Dr. Reed put me at ease immediately. Her genuine care and expertise are outstanding. I'm so grateful to be a patient here.",
    name: "Jessica L.",
    avatar: patientAvatars[2],
  },
];

export default function TestimonialsPage() {
  return (
    <main className="container mx-auto px-4 py-16 animate-fade-in">
      <section className="text-center mb-12">
        <h1 className="text-5xl font-headline font-bold mb-4 text-primary">What Our Patients Say</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Hear from individuals whose lives have been positively impacted by the care at Maple Clinic.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {testimonialsData.map((testimonial) => (
          <Card key={testimonial.name} className="bg-background/80 backdrop-blur-sm shadow-md p-6 flex flex-col">
            <CardHeader className="p-0 mb-4">
              <div className="flex items-center gap-4">
                <Image
                  src={testimonial.avatar.imageUrl}
                  alt={testimonial.avatar.description}
                  width={100}
                  height={100}
                  className="rounded-full w-20 h-20 object-cover"
                  placeholder="blur"
                  blurDataURL={testimonial.avatar.imageUrl.replace('100/100', '10/10')}
                  data-ai-hint={testimonial.avatar.imageHint}
                />
                <div>
                  <CardTitle className="font-headline text-lg text-primary">{testimonial.name}</CardTitle>
                  <CardDescription className="text-accent font-medium">Satisfied Patient</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-grow p-0">
              <blockquote className="text-muted-foreground italic text-lg leading-relaxed">
                "{testimonial.quote}"
              </blockquote>
            </CardContent>
          </Card>
        ))}
      </section>
    </main>
  );
}
