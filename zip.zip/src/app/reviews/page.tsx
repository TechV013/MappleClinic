
'use client';

import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Star, Quote } from 'lucide-react';

const patientAvatars = [
  PlaceHolderImages.find(img => img.id === 'avatar-patient-f1') || { imageUrl: 'https://picsum.photos/seed/patient1/200/200', description: 'Sarah K.', imageHint: 'smiling woman'},
  PlaceHolderImages.find(img => img.id === 'avatar-patient-m1') || { imageUrl: 'https://picsum.photos/seed/patient2/200/200', description: 'Mark T.', imageHint: 'smiling man'},
  PlaceHolderImages.find(img => img.id === 'avatar-patient-f2') || { imageUrl: 'https://picsum.photos/seed/patient3/200/200', description: 'Jessica L.', imageHint: 'elderly person'},
];

const reviews = [
  {
    quote: "Dr. Reed and her staff are exceptionally kind and knowledgeable. I always feel heard and well-cared for. Maple Clinic has truly made a difference in my health journey.",
    name: "Sarah K.",
    rating: 5,
    date: "February 2024",
    avatar: patientAvatars[0],
  },
  {
    quote: "The clinic is always clean, welcoming, and runs efficiently. Dr. Reed's clear explanations and proactive approach to my health have been invaluable. Highly recommend!",
    name: "Mark T.",
    rating: 5,
    date: "January 2024",
    avatar: patientAvatars[1],
  },
  {
    quote: "I was initially nervous about finding a new doctor, but Dr. Reed put me at ease immediately. Her genuine care and expertise are outstanding. I'm so grateful to be a patient here.",
    name: "Jessica L.",
    rating: 5,
    date: "December 2023",
    avatar: patientAvatars[2],
  },
  {
    quote: "Maple Clinic offers the most professional atmosphere I've experienced. The diagnostic results were explained in a way I could actually understand. Excellent follow-up care as well.",
    name: "Robert M.",
    rating: 4,
    date: "November 2023",
    avatar: { imageUrl: 'https://picsum.photos/seed/patient-m2/200/200', description: 'Robert M.', imageHint: 'smiling man' },
  },
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground'}`}
        />
      ))}
    </div>
  );
}

export default function ReviewsPage() {
  return (
    <main className="container mx-auto px-4 py-16 animate-fade-in">
      <section className="text-center mb-16">
        <h1 className="text-5xl font-headline font-bold mb-4 text-primary">Patient Feedback</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          We pride ourselves on the trust and relationships we build with our patients. Here is what they have to say about their experience at Maple Clinic.
        </p>
        <div className="mt-8 flex justify-center items-center gap-4">
          <div className="text-4xl font-bold text-primary">4.9/5</div>
          <div className="text-left">
            <StarRating rating={5} />
            <div className="text-sm text-muted-foreground">Based on 500+ patient reviews</div>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {reviews.map((review) => (
          <Card key={review.name} className="relative bg-background border shadow-sm overflow-hidden group hover:shadow-md transition-shadow">
            <Quote className="absolute top-6 right-6 h-12 w-12 text-primary/10 transition-transform group-hover:scale-110" />
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="relative h-16 w-16 rounded-full overflow-hidden border-2 border-primary/20">
                <Image
                  src={review.avatar.imageUrl}
                  alt={review.avatar.description}
                  fill
                  className="object-cover"
                  data-ai-hint={review.avatar.imageHint}
                />
              </div>
              <div className="space-y-1">
                <CardTitle className="text-lg font-headline">{review.name}</CardTitle>
                <div className="flex items-center gap-2">
                  <StarRating rating={review.rating} />
                  <span className="text-xs text-muted-foreground">{review.date}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground italic leading-relaxed">
                "{review.quote}"
              </p>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="mt-20 text-center bg-primary/5 p-12 rounded-2xl border">
        <h3 className="text-3xl font-headline font-bold mb-4">Are You a Patient?</h3>
        <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
          We value your feedback. Sharing your experience helps us continue to improve our care for the entire community.
        </p>
        <div className="flex justify-center gap-4">
          <button className="px-6 py-2 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors">
            Leave a Review
          </button>
        </div>
      </section>
    </main>
  );
}
