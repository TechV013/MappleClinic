
import type {Metadata} from 'next';
import './globals.css';
import { Header } from '@/components/header';
import { InteractiveBackground } from '@/components/interactive-background';

export const metadata: Metadata = {
  title: 'Maple Clinic | Expert Medical Care',
  description: 'Providing compassionate and expert medical care with a focus on your well-being.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen flex flex-col overflow-x-hidden">
        <InteractiveBackground />
        <Header />
        <div className="flex-1">
          {children}
        </div>
        <footer className="border-t py-8 bg-muted/30 mt-auto">
          <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
            © {new Date().getFullYear()} Maple Clinic. All rights reserved.
          </div>
        </footer>
      </body>
    </html>
  );
}
