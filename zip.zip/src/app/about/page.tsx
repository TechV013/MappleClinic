import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';

// Placeholder for doctor's image, fetched from placeholder-images.json
const doctorPlaceholder = PlaceHolderImages.find(img => img.imageHint === 'doctor portrait');
const doctorImage = doctorPlaceholder ? {
  src: doctorPlaceholder.imageUrl,
  alt: doctorPlaceholder.description,
  width: 400, // Smaller image for profile display
  height: 500,
  imageHint: doctorPlaceholder.imageHint
} : {
  src: 'https://picsum.photos/seed/doctor/400/500', // Fallback image
  alt: 'Dr. Evelyn Reed profile picture',
  width: 400,
  height: 500,
  imageHint: 'doctor portrait',
};

export default function AboutPage() {
  return (
    <main className="container mx-auto px-4 py-16 animate-fade-in">
      <section className="text-center mb-12">
        <h1 className="text-5xl font-headline font-bold mb-4 text-primary">About Dr. Evelyn Reed</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Dedicated to your health and well-being with expertise and compassion.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-12 items-center">
        <div className="md:col-span-1 flex justify-center">
          <Image
            src={doctorImage.src}
            alt={doctorImage.alt}
            width={doctorImage.width}
            height={doctorImage.height}
            className="rounded-lg shadow-xl object-cover w-full max-w-sm"
            placeholder="blur"
            blurDataURL={doctorImage.src.replace('400/500', '10/10')} // Basic blur effect
            data-ai-hint={doctorImage.imageHint}
          />
        </div>
        <div className="md:col-span-2">
          <Card className="bg-background/80 backdrop-blur-sm shadow-md p-6">
            <CardHeader>
              <CardTitle className="font-headline text-primary text-3xl">Dr. Evelyn Reed, MD</CardTitle>
              <CardDescription className="text-accent">Family Medicine Specialist</CardDescription>
            </CardHeader>
            <CardContent>
              <h3 className="text-2xl font-headline font-semibold text-primary mb-4 mt-6">My Philosophy</h3>
              <p className="text-muted-foreground mb-4 leading-relaxed">
                My approach to medicine is rooted in building a strong, trusting relationship with each patient. I believe that true healing involves understanding not just the symptoms, but the whole person – their lifestyle, their concerns, and their goals. I am committed to providing personalized, evidence-based care with a focus on preventative strategies and empowering you to take an active role in your health.
              </p>

              <h3 className="text-2xl font-headline font-semibold text-primary mb-4">Qualifications & Experience</h3>
              <ul className="list-disc list-inside text-muted-foreground leading-relaxed space-y-2">
                <li><span className="font-medium">Medical Degree:</span> University of Toronto, Faculty of Medicine</li>
                <li><span className="font-medium">Residency:</span> McMaster University, Family Medicine Program</li>
                <li><span className="font-medium">Board Certified:</span> College of Family Physicians of Canada</li>
                <li><span className="font-medium">Years of Practice:</span> Over 15 years in family medicine</li>
                <li><span className="font-medium">Special Interests:</span> Preventative health, chronic disease management, women's health</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>
       <section className="mt-16 text-center">
         <Link href="/contact">
           <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10">
             Schedule Your Appointment
           </Button>
         </Link>
       </section>
    </main>
  );
}
