'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Phone, Mail, MapPin, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setIsSubmitting(false);
    setSubmitted(true);
    toast({
      title: "Request Sent!",
      description: "We'll contact you shortly to confirm your appointment.",
    });
  }

  return (
    <main className="container mx-auto px-4 py-16 animate-fast-in">
      <section className="text-center mb-16">
        <h1 className="text-5xl font-headline font-bold mb-4 text-primary">Get In Touch</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          We're dedicated to your care. Schedule your visit or reach out with any questions.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
        <div className="space-y-8">
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-none">
            <CardHeader>
              <CardTitle className="font-headline text-primary text-3xl">Maple Clinic</CardTitle>
              <CardDescription className="text-accent font-semibold">Your Health Partner</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4 text-muted-foreground p-3 rounded-xl hover:bg-muted/50 transition-colors">
                <MapPin className="h-6 w-6 text-primary shrink-0" />
                <div>
                  <p className="font-bold text-foreground">123 Maple Street</p>
                  <p>Ottawa, ON K1A 0B2</p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-muted-foreground p-3 rounded-xl hover:bg-muted/50 transition-colors">
                <Phone className="h-6 w-6 text-primary shrink-0" />
                <p className="font-bold text-foreground">(613) 555-1234</p>
              </div>
              <div className="flex items-center gap-4 text-muted-foreground p-3 rounded-xl hover:bg-muted/50 transition-colors">
                <Mail className="h-6 w-6 text-primary shrink-0" />
                <p className="font-bold text-foreground">info@mapleclinic.ca</p>
              </div>
            </CardContent>
          </Card>

          <div className="rounded-3xl overflow-hidden shadow-inner bg-muted h-72 flex flex-col items-center justify-center border-2 border-dashed">
            <MapPin className="h-10 w-10 text-muted-foreground/30 mb-4" />
            <span className="text-muted-foreground font-medium">Interactive Map Loading...</span>
          </div>
        </div>

        <Card className="bg-white/90 backdrop-blur-md shadow-2xl border-none p-4">
          <CardHeader>
            <CardTitle className="font-headline text-primary text-3xl">Book Appointment</CardTitle>
            <CardDescription>
              Fast and secure online booking.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AnimatePresence mode="wait">
              {!submitted ? (
                <motion.form 
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  onSubmit={handleSubmit} 
                  className="space-y-5"
                >
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" name="name" required placeholder="E.g., Jane Doe" className="bg-background/50" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" name="email" type="email" required placeholder="jane@example.com" className="bg-background/50" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input id="phone" name="phone" type="tel" required placeholder="(613) 555-0000" className="bg-background/50" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      name="message"
                      rows={4}
                      placeholder="Reason for your visit..."
                      required
                      className="bg-background/50 resize-none"
                    />
                  </div>
                  <motion.div whileTap={{ scale: 0.98 }}>
                    <Button type="submit" className="w-full py-6 text-lg font-bold shadow-lg" disabled={isSubmitting}>
                      {isSubmitting ? 'Sending...' : 'Request Appointment'}
                    </Button>
                  </motion.div>
                </motion.form>
              ) : (
                <motion.div 
                  key="success"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-12 text-center"
                >
                  <div className="inline-flex p-4 rounded-full bg-accent/20 text-accent mb-6">
                    <CheckCircle2 className="h-12 w-12" />
                  </div>
                  <h3 className="text-2xl font-bold text-primary mb-2">Request Received!</h3>
                  <p className="text-muted-foreground mb-8">
                    We'll call or email you within 24 hours to confirm.
                  </p>
                  <Button variant="outline" onClick={() => setSubmitted(false)}>
                    Send Another Request
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}