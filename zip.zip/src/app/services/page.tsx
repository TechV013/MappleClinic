'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Stethoscope, Pill, HeartPulse, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

const serviceImages = [
  PlaceHolderImages.find(img => img.id === 'service-checkup-detail') || { imageUrl: 'https://picsum.photos/seed/checkup/800/600', description: 'Checkup', imageHint: 'medical examination'},
  PlaceHolderImages.find(img => img.id === 'service-consultation-detail') || { imageUrl: 'https://picsum.photos/seed/consultation/800/600', description: 'Consultation', imageHint: 'doctor patient'},
  PlaceHolderImages.find(img => img.id === 'service-prevention-detail') || { imageUrl: 'https://picsum.photos/seed/prevention/800/600', description: 'Prevention', imageHint: 'health wellness'},
  PlaceHolderImages.find(img => img.id === 'service-diagnostic-detail') || { imageUrl: 'https://picsum.photos/seed/diagnostic/800/600', description: 'Diagnostic', imageHint: 'medical laboratory'},
];

const servicesData = [
  {
    title: 'Health Assessments',
    description: 'Thorough physical examinations using modern diagnostic tools.',
    image: serviceImages[0],
    icon: Stethoscope
  },
  {
    title: 'Consultations',
    description: 'In-depth focus on specific medical concerns with personalized paths.',
    image: serviceImages[1],
    icon: Pill
  },
  {
    title: 'Wellness Care',
    description: 'Proactive strategies including nutritional guidance and coaching.',
    image: serviceImages[2],
    icon: HeartPulse
  },
  {
    title: 'Rapid Diagnostics',
    description: 'On-site lab services providing rapid and accurate test results.',
    image: serviceImages[3],
    icon: Activity
  },
];

export default function ServicesPage() {
  return (
    <main className="container mx-auto px-4 py-16 animate-fast-in">
      <section className="text-center mb-16">
        <h1 className="text-5xl font-headline font-bold mb-4 text-primary">Our Services</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Comprehensive medical care designed to support your lifelong health.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
        {servicesData.map((service, i) => (
          <motion.div
            key={service.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="flex flex-col bg-white/80 backdrop-blur-sm border-none shadow-xl overflow-hidden group h-full">
              <div className="relative h-64 overflow-hidden">
                <Image
                  src={service.image.imageUrl}
                  alt={service.image.description}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                  data-ai-hint={service.image.imageHint}
                />
                <div className="absolute inset-0 bg-black/10 transition-opacity group-hover:opacity-0" />
              </div>
              <CardHeader className="relative pt-12">
                <div className="absolute -top-10 left-8 p-4 bg-primary rounded-2xl shadow-xl text-primary-foreground transform transition-transform group-hover:scale-110 group-hover:-translate-y-1">
                  <service.icon className="h-8 w-8" />
                </div>
                <CardTitle className="font-headline text-2xl text-primary">{service.title}</CardTitle>
                <CardDescription className="text-base text-muted-foreground">
                  {service.description}
                </CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto pb-8 px-8">
                <Link href="/contact" className="w-full">
                  <motion.div whileTap={{ scale: 0.98 }}>
                    <Button className="w-full font-bold shadow-md" variant="outline">
                      Schedule Service
                    </Button>
                  </motion.div>
                </Link>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </section>
    </main>
  );
}