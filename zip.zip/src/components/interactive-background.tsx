'use client';

import { motion, useMotionValue, useSpring } from 'framer-motion';
import { useEffect, useState } from 'react';

export function InteractiveBackground() {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const [isClient, setIsClient] = useState(false);

  // Faster springs for better responsiveness
  const springX = useSpring(mouseX, { damping: 30, stiffness: 300 });
  const springY = useSpring(mouseY, { damping: 30, stiffness: 300 });

  useEffect(() => {
    setIsClient(true);
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  if (!isClient) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden opacity-25">
      <motion.div
        className="absolute w-[600px] h-[600px] rounded-full bg-primary/20 blur-[120px] will-change-transform"
        style={{
          x: springX,
          y: springY,
          translateX: '-50%',
          translateY: '-50%',
          translateZ: 0, // Force GPU acceleration
        }}
      />
      <motion.div
        className="absolute w-[400px] h-[400px] rounded-full bg-accent/20 blur-[100px] will-change-transform"
        style={{
          x: springX,
          y: springY,
          translateX: '10%',
          translateY: '10%',
          translateZ: 0,
        }}
      />
    </div>
  );
}